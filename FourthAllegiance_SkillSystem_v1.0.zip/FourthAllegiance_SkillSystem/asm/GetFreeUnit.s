@ Fourth Allegiance for the Skill System: replacement for GetFreeUnit (0x08017838).
@
@ Vanilla GetFreeUnit(faction) returns the first empty unit struct from faction+1 to faction+0x3F.
@ LoadUnit now calls it with faction 3 for fourth-allegiance units (see the 0x17BC2 patch in the installer),
@ and this version searches only ids 0xC1 .. 0xC0+FA_PurpleUnitCount for them, returning NULL when every slot
@ is taken (LoadUnit then skips the unit, as it does for full red or green rosters).
@ Ids above the last slot point at a shared empty struct, so they must never be handed out.
@ Every other faction behaves exactly as before.
@
@ Hooked with: ORG 0x17838; SHORT 0x4B00 0x4718; POIN FA_GetFreeUnit|1
@ The installer appends one WORD after this code: FA_PurpleUnitCount.
.thumb
.org 0x0
	push  {r4, lr}
	mov   r2, r0
	cmp   r0, #3
	beq   Purple
	cmp   r0, #0xC0
	bne   Other
Purple:
	mov   r2, #0xC0
	ldr   r3, Count
	add   r3, r2
	add   r3, #1             @ stop before 0xC1 + count
	b     Start
Other:
	mov   r3, r2
	add   r3, #0x40
Start:
	add   r2, #1
	ldr   r4, UnitLookup
Loop:
	cmp   r2, r3
	bge   None
	mov   r0, #0xFF
	and   r0, r2
	lsl   r0, #2
	ldr   r0, [r4, r0]
	cmp   r0, #0
	beq   Next
	ldr   r1, [r0]           @ character pointer: 0 means the slot is free
	cmp   r1, #0
	beq   Found
Next:
	add   r2, #1
	b     Loop
None:
	mov   r0, #0
Found:
	pop   {r4}
	pop   {r1}
	bx    r1
.align
UnitLookup:
	.long 0x0859A5D0         @ gUnitLookup
Count:
	@ WORD FA_PurpleUnitCount (appended by the installer)
