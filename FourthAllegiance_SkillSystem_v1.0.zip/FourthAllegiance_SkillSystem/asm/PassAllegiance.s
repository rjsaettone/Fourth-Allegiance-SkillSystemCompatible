@ Fourth Allegiance for the Skill System: the movement ARM hook at ROM 0x800 (copied to IWRAM 0x3003D28) is used by
@ both the Skill System's Pass skill (PassCheck) and the fourth allegiance (Kirb's NewMovementCheck). This routine
@ replaces both: a unit may move through a tile if AreAllegiancesAllied (the fourth-allegiance version, which reads
@ the chapter's relations bitmap) says the two units are allied, or if the moving unit has Pass.
@ Returns to 0x3003D34 with the Z flag set when the mover may cross the tile.
@ r3+0xA = the moving unit's index byte, r7 = the index byte of the unit standing on the tile (from gMapUnit).
@ The installer appends: POIN AreAllegiancesAllied, POIN SkillTester, WORD PassID.
.thumb
.org 0x0
push  {r0-r6,r14}
ldrb  r4, [r3,#0xA]     @ the mover's index; r4 survives the calls below (r3 doesn't)
ldr   r0, AreAllied
mov   r14, r0
mov   r0, r4
mov   r1, r7
.short 0xF800           @ AreAllegiancesAllied(mover, occupant)
cmp   r0, #1
beq   GoBack            @ allied: Z set, the tile can be crossed
ldr   r0, GetUnitPtr
mov   r14, r0
mov   r0, r4
.short 0xF800           @ GetUnit(index) -> unit struct of the mover
ldr   r1, SkillTesterPtr
mov   r14, r1
ldr   r1, PassIDw
.short 0xF800           @ SkillTester(unit, PassID)
cmp   r0, #1            @ Z set if the mover has Pass
GoBack:
pop   {r0-r6}
pop   {r4}
mov   r14, r4
ldr   r4, GoBackAddress
bx    r4
.align
GetUnitPtr:
.long 0x08019430
GoBackAddress:
.long 0x03003D34
AreAllied:          @ POIN AreAllegiancesAllied (appended by the installer)
SkillTesterPtr = AreAllied + 4   @ POIN SkillTester
PassIDw        = AreAllied + 8   @ WORD PassID
