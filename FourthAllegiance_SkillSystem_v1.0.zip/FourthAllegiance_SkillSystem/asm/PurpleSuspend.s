@ Fourth Allegiance for the Skill System: suspend-save chunk for fourth-allegiance units.
@
@ ExpandedModularSave calls FA_SavePurpleUnits(r0 = SRAM address, r1 = chunk size) when suspending and
@ FA_LoadPurpleUnits(same) when resuming. One record per unit id from 0xC1 upward:
@   +0x00  the 0x38-byte "other unit" record ExpandedModularSave uses for red and green units
@          (made by its own PackOtherSuspendSaveUnit / UnpackOtherSuspendSaveUnit)
@   +0x38  the unit's debuff table entry (DebuffEntrySize bytes), which the Debuffs chunk doesn't cover
@          for this allegiance
@ The record count is chunk size / (0x38 + DebuffEntrySize).
@
@ Entry points: FA_SavePurpleUnits = start + 1, FA_LoadPurpleUnits = start + 0x84 + 1 (see the installer).
@ The installer appends four words: PackOtherSuspendSaveUnit, UnpackOtherSuspendSaveUnit, GetUnitDebuffEntry,
@ DebuffEntrySize.
.thumb
.org 0x0

.global FA_SavePurpleUnits
FA_SavePurpleUnits:
	push  {r4-r7, lr}
	sub   sp, #0x40
	mov   r4, r0              @ r4 = SRAM destination
	mov   r0, r1
	ldr   r1, DebSize
	add   r1, #0x38
	swi   6                   @ r0 = records
	mov   r6, r0
	mov   r5, #0xC1
SaveLoop:
	cmp   r6, #0
	ble   SaveEnd
	ldr   r3, GetUnitP
	mov   r0, r5
	bl    BXR3
	cmp   r0, #0
	beq   SaveEnd
	mov   r7, r0
	mov   r1, r0
	mov   r0, sp
	ldr   r3, PackP
	bl    BXR3                @ Pack(buffer, unit)
	mov   r0, sp              @ clear the debuff bytes
	add   r0, #0x38
	ldr   r2, DebSize
	mov   r1, #0
SaveClear:
	sub   r2, #1
	bmi   SaveClearDone
	strb  r1, [r0, r2]
	b     SaveClear
SaveClearDone:
	ldr   r0, [r7]
	cmp   r0, #0
	beq   SaveWrite           @ empty slot: no debuffs
	mov   r0, r7
	ldr   r3, GetEntryP
	bl    BXR3
	cmp   r0, #0
	beq   SaveWrite
	mov   r1, sp
	add   r1, #0x38
	ldr   r2, DebSize
SaveCopy:
	sub   r2, #1
	bmi   SaveWrite
	ldrb  r3, [r0, r2]
	strb  r3, [r1, r2]
	b     SaveCopy
SaveWrite:
	ldr   r2, DebSize
	add   r2, #0x38
	mov   r7, r2
	mov   r0, sp
	mov   r1, r4
	ldr   r3, WriteSramP
	bl    BXR3                @ WriteAndVerifySramFast(buffer, sram, size)
	add   r4, r7
	add   r5, #1
	sub   r6, #1
	b     SaveLoop
SaveEnd:
	add   sp, #0x40
	pop   {r4-r7}
	pop   {r0}
	bx    r0
BXR3:
	bx    r3

.align
.global FA_LoadPurpleUnits
FA_LoadPurpleUnits:
	push  {r4-r7, lr}
	sub   sp, #0x40
	mov   r4, r0              @ r4 = SRAM source
	mov   r0, r1
	ldr   r1, DebSize
	add   r1, #0x38
	swi   6
	mov   r6, r0
	mov   r5, #0xC1
LoadLoop:
	cmp   r6, #0
	ble   LoadEnd
	ldr   r3, ReadSramPP
	ldr   r3, [r3]
	mov   r0, r4
	mov   r1, sp
	ldr   r2, DebSize
	add   r2, #0x38
	bl    BXR3b               @ ReadSramFast(sram, buffer, size)
	ldr   r3, GetUnitP
	mov   r0, r5
	bl    BXR3b
	cmp   r0, #0
	beq   LoadEnd
	mov   r7, r0
	mov   r1, sp
	ldr   r3, UnpackP
	bl    BXR3b               @ Unpack(unit, buffer)
	ldr   r0, [r7]
	cmp   r0, #0
	beq   LoadNext
	mov   r0, r7
	ldr   r3, GetEntryP
	bl    BXR3b
	cmp   r0, #0
	beq   LoadNext
	mov   r1, sp
	add   r1, #0x38
	ldr   r2, DebSize
LoadCopy:
	sub   r2, #1
	bmi   LoadNext
	ldrb  r3, [r1, r2]
	strb  r3, [r0, r2]
	b     LoadCopy
LoadNext:
	ldr   r2, DebSize
	add   r2, #0x38
	add   r4, r2
	add   r5, #1
	sub   r6, #1
	b     LoadLoop
LoadEnd:
	add   sp, #0x40
	pop   {r4-r7}
	pop   {r0}
	bx    r0
BXR3b:
	bx    r3

.align
GetUnitP:   .long 0x08019431  @ GetUnit
WriteSramP: .long 0x080D184D  @ WriteAndVerifySramFast
ReadSramPP: .long 0x030067A0  @ pointer to ReadSramFast
PackP:      @ POIN (ESU_SaveGameUnits - 0x90)   PackOtherSuspendSaveUnit
UnpackP     = PackP + 4       @ POIN (ESU_SaveGameUnits - 0x48)   UnpackOtherSuspendSaveUnit
GetEntryP   = PackP + 8       @ POIN GetUnitDebuffEntry
DebSize     = PackP + 12      @ WORD DebuffEntrySize
