# Fourth Allegiance for the Skill System (FE8U)

Version 1.0, October 2026.

This adds a fourth army to Fire Emblem: The Sacred Stones. Its units are purple and take their own phase after the green phase. They fight anyone the chapter makes them hostile to: the player, the enemy, other NPCs, or all three. Unlike the original hack, this version works alongside the FE8 Skill System.

It's built on Kirb's [FE8U Fourth Allegiance](https://github.com/Kirbseverywhere/FE8U-Fourth-Allegiance). Kirb's README says the original is "incompatible with the skill system family of engine hacks". This release makes it compatible.

## Credits

- **Kirb**: the original FE8U Fourth Allegiance (2020): the phase cycle, the allegiance checks, the NEUTRAL PHASE banner, the minimug palette, the AI table patches, and the faction relations bitmap. It's released into the public domain (the Unlicense; see `LICENSE`).
- Kirb's own thanks, passed on: **Shuusuke**, **Shane**, **Peerless** (the NEUTRAL PHASE banner), and **HyperGammaSpaces**.
- **The FE8 Skill System contributors**: the turn loop, Armor March and Vigor Dance routines patched in `SkillSystemPatches/` are theirs. See the Skill System's `CREDITS.md`.
- Adapted for the Skill System by: **[YOUR NAME]**

## What changed from Kirb's version

- **The movement hook at 0x800.** Kirb's hack and the Skill System's Pass skill both replace the same movement routine. `asm/PassAllegiance.s` replaces both of them. A unit can cross a tile if the two units are allied under the chapter's relations, or if the moving unit has Pass.
- **Unit RAM.** Kirb stored purple units at 0x2026E30, which the Skill System uses as its unit load buffer. They now live in free EWRAM, set by `FA_PurpleUnitRam` (default 0x0203F600).
- **Skill System loops.** Some routines walk a whole faction by unit id. On the purple phase they either never stopped (the game froze) or skipped purple units:
  - the start/end-of-turn loop (TurnLoop)
  - Armor March
  - the Vigor Dance reset

  These are patched (see `SkillSystemPatches/`). Purple units get start-of-turn effects (buffs such as Hone) on their own phase.
- **Bounded unit slots.** Ids past the last purple slot used to be NULL. They now point at an empty unit, so loops that walk all ids up to 0xFF no longer read a NULL unit. `GetFreeUnit` is replaced (`asm/GetFreeUnit.s`) so only real slots are handed out. If every slot is taken, extra purple units are skipped. Kirb's version froze in that case.
- **Suspend.** Kirb's ExpandedModularSave is left out because the Skill System has its own. Instead, a chunk for it saves purple units and their debuff entries (`asm/PurpleSuspend.s`).
- **Relations.** All 79 vanilla chapter rows get the default relations. Kirb's version set the first 13.
- **Fog of war.** Only blue and green units give the player vision, as in vanilla. Kirb's version had two problems in fog. On the enemy phase, purple units past the fifth slot were left off the unit map, so red units could walk through them. On the purple phase, every red and purple unit hidden by fog was left off it. The purple phase now builds the unit map the way the enemy phase does, for all slots. Fog still hides those units from the player's view.

## Requirements

- An **FE8U Skill System buildfile**. This release was tested against the [Skill System](https://github.com/FireEmblemUniverse/SkillSystem_FE8) master at commit `7e427b7` (2026-10-19). An older or modified copy may need the patches applied by hand (they're small; see the `.diff` files).
- The **ColorzCore** that ships with the Skill System. The installer uses `#if` and comparison operators.
- **Free EWRAM** for `(FA_PurpleUnitCount + 1) * 0x48` bytes at `FA_PurpleUnitRam`.
  - Purple units' debuff entries take another `FA_PurpleUnitCount * 8` bytes right after the Skill System's debuff tables (0x203F540 in a stock build).
  - The installer `ASSERT`s that the two areas don't overlap.
  - With the defaults (20 units), the hack uses 0x203F538 to 0x203FBE8. That range is unused in a stock Skill System build. If your own hacks use RAM there, move `FA_PurpleUnitRam`.
- **Suspend space** of `FA_PurpleUnitCount * 0x40` bytes. The default of 20 needs $500, and the stock suspend block has $567 free after $2911.

## Installing

1. **Copy this folder** into your buildfile, for example to `EngineHacks/ExternalHacks/FourthAllegiance_SkillSystem/`.

2. **Include it after the Skill System** in `ROMBuildfile.event`:

   ```
   #include "EngineHacks/_MasterHackInstaller.event"
   #include "EngineHacks/ExternalHacks/FourthAllegiance_SkillSystem/FourthAllegiance.event"
   ```

   It must come after `_MasterHackInstaller.event` because it overrides the Skill System's 0x800 hook.

3. **Patch three Skill System files** (`SkillSystemPatches/`):

   | Patch | Replaces |
   |---|---|
   | `TurnLoop/StartOfTurn_CalcLoop.s` + `.lyn.event` | `EngineHacks/Necessary/CalcLoops/TurnLoop/` |
   | `ArmorMarch/armormarchskill.s` + `.lyn.event` | `EngineHacks/SkillSystem/Skills/AuraSkills/ArmorMarch/` |
   | `VigorDance/vigordancereset.s` + `.lyn.event` | `EngineHacks/SkillSystem/Skills/StandaloneSkills/VigorDance/` |

   - If your Skill System matches commit `7e427b7`, copy the `.s` and `.lyn.event` files over the originals.
   - Otherwise, apply the `.diff` files to your `.s` files (`git apply` from the buildfile root, or by hand) and rebuild each `.lyn.event` with the folder's `AssembleLyn` script or `lyn`.

   Only use the TurnLoop patch together with this hack. It changes the order of phases the turn loop expects. Without a purple phase, green units would lose their end-of-turn effects.

4. **Declare the suspend chunk** in `EngineHacks/Necessary/ExpandedModularSave/ExModularSave.event`. Put it in the suspend list, after the Gaiden magic chunk and before `DeclSaveChunkEnd`:

   ```
   // Fourth Allegiance: purple units (20 units * $40 = $500)
   DeclSaveChunk($2911, $0500, FA_SavePurpleUnits, FA_LoadPurpleUnits)
   ```

   - The size is `FA_PurpleUnitCount * (0x38 + DebuffEntrySize)`, which is `$40` per unit in a stock build.
   - It has to be a number here, because `ExModularSave.event` is assembled before this hack's definitions.
   - Suspends made before you add the chunk won't contain purple units.

5. **Optional settings.** Define these before the `#include` to change them:

   | Define | Default | Meaning |
   |---|---|---|
   | `FA_PurpleUnitCount` | 20 | Purple units on the map at once (1 to 62). Change the suspend chunk size to match. |
   | `FA_PurpleUnitRam` | 0x0203F600 | Where the purple unit structs live. |
   | `FA_NO_DEFAULT_RELATIONS` | (undefined) | Skip writing the default relations into every chapter row. Use this if you set them all yourself or your chapter table is repointed. |

   The hack also uses `ChapterDataTable` and `ChapterDataTableEntSize`. The Skill System defines them in `CustomDefinitions.event`.

## Using it

### Purple units

A unit's allegiance is in bits 1–2 of its level byte; 3 is the fourth allegiance. In a `UNIT` line, the level byte is `level * 8 + 6`, plus 1 for autolevel. For example, level 10 with autolevel is `0x57`. These macros help:

```
#define Purple(lv)      "((lv)*8 + 7)"   // autolevel on
#define PurpleFixed(lv) "((lv)*8 + 6)"
UNIT Bandit Fighter 0x0 Purple(10) [8,20] 0 0 0 0 [SteelAxe, HandAxe] NoAI
```

Load them with `LOAD1` like any other units. Opening scenes with a preparations screen work too. In FEBuilder's unit editor, Kirb notes that allegiance 3 shows up as "Defeat".

### Faction relations

Each chapter has a relations bitmap: the SHORT at +0x26 of its chapter data row. It's four groups of four bits, one group per faction in the order blue, green, red, purple. Each group says which factions that one treats as allies, in the same order. The default is vanilla's relations for blue, green and red, with purple hostile to everyone.

To change a chapter's relations, put this in its events (or anywhere after the include):

```
// chapter 0x05: purple fights the player but leaves the red army alone
FA_SetRelations(0x05, FactionRelations(1,1,0,0,  1,1,0,0,  0,0,1,1,  0,0,1,1))
//                                     blue      green     red       purple
```

Keep the relations symmetric: if red counts purple as an ally, purple should count red as one too. Each unit should be allied with its own faction.

### Music

- The purple phase plays the song at chapter data **+0x1C**, or **+0x1E** while event flag 4 is set.
- In vanilla, +0x1C holds a copy of the player phase song. Kirb's code also moves the flag-4 green phase song to +0x20.

### Events

- `CHECK_ALLEGIANCE` returns 3 for purple units.
- Purple units use the green units' escape-point table.

## Limits

These were found by reading the Skill System's source and by scanning FE8's own code for unit loops that stop at id 0xBF (the last red slot). The list may not be complete: a loop written some other way could still skip purple units. Unless marked as seen in testing, each item comes from reading the code.

### Skill System features that skip purple units

- Weather skills (Snow Warning, Sandstream, Drizzle, Drought, Airlock): a purple holder doesn't set the weather.
- Keep Up, Indoor March and Nature Rush.
- Galeforce: at the start of the purple phase it's reset only for the first four purple slots.
- Staff AI: no staff user ever picks a purple unit as a target. Purple healers don't heal each other, and enemy Sleep, Silence or Berserk users never aim at purple units.
- The enemy range display.
- The stat screen's talk target.
- Map HP bars: they're drawn by the same FE8 loop as the status icons below, so purple units don't get them.
- The optional `STAIRS_ASM` and the Freeze dragon vein.

### FE8 routines that skip purple units

- **Clearing units by event:** `CLEA`, `CLEN` and `CLEE` clear blue, green and red units only. No command clears the purple army; remove purple units one at a time with `KILL` or `DISA`.
- **Changing AI by event:** `CHAI` and `CHAI2` don't reach purple units. Load them with the AI they need, or change it with your own ASMC.
- **Map icons:** status-effect icons such as poison and sleep aren't drawn over purple units (seen in testing).
- **Enemy AI:**
  - Units on ballistae don't target purple units.
  - When the AI judges danger (where it's safe to stand, which weapon to equip), it ignores threats from purple units.
  - AI that goes after one particular character won't find that character if it's purple.
- **Roofs:** a purple unit under a roof isn't hidden after a map change.
- **Chapter status screen:** it doesn't show a purple boss.
- **Goals:** "defeat all enemies" goals and the victory-music threshold count red units only. Purple units don't have to be defeated.

### Other limits

- The Link Arena is untested. Its units use the same ids (0xC1–0xC5) and the same fourth map-sprite palette.
- Your own hacks may loop over a faction by id, from `phase + 1` until they reach 0x3F, 0x55 or 0xB3. On the purple phase they never reach those values. Add a stop at 0xFF, as the patched Armor March does.

## Testing done

Tested in mGBA on a stock Skill System build (commit `7e427b7`) with 14 purple units on the test map and a preparations screen:

- **Loading and phases:** purple units load in the opening scene before preparations. The phase order is player → enemy → green → purple. The NEUTRAL PHASE banner and purple map sprites show.
- **Combat:** purple and red units attack each other on both phases, and purple units attack the player (battle animations included).
- **Pass:** a unit with Pass moves through red and purple units. Without Pass, they block it.
- **Skill effects on the purple phase:** Renewal heals a purple unit at the start of its phase. A start-of-turn buff (Hone) applies to an adjacent purple ally and is stored in its debuff entry.
- **Suspend:** suspend → title → resume restores every purple unit (position, HP, state) and its debuff entry, even after the RAM was wiped in between.
- **Unit cap:** with `FA_PurpleUnitCount` set to 10 and 14 purple units placed, 10 load, the rest are skipped, and play continues normally.
- **Stat screen and minimug:** both show for purple units.
- **Fog of war** (vision 3): the player's fog map is identical with purple units on the map, removed, or with red units removed. Purple units in fog are hidden from view on every phase. On the enemy and purple phases, every red and purple unit stays on the unit map.

It's also running in a full hack: The First Roost, a Skill System buildfile with custom engine changes. There, purple units loaded before a preparations screen, fought the red army for several turns with turn events firing on time, survived a suspend, and took player attacks (forecast, battle and EXP).

## Rebuilding the assembly

- The `.dmp` files come from `arm-none-eabi-as -mthumb file.s` and `arm-none-eabi-objcopy -O binary`.
- Each `.s` file ends at the label where the installer appends its literals, so the `.dmp` holds only the code.
- `src/FourthAllegiance.lyn.event` is Kirb's C (`src/FourthAllegiance.c`), unchanged. Rebuilding it needs FE-CLib; see Kirb's repository.

## License

Kirb's original is released into the public domain under the Unlicense (`LICENSE`). This adaptation is released the same way.
